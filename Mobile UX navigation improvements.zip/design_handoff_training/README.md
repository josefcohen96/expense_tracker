# Handoff: Training / Workout page — "הזירה" (Arena)

## Overview

The workout page already has a full gamification engine — XP, levels, ranks, streak, achievements and a
skill-progression guide — but all of it sits in a **card at the top of the page**, while the workout
itself is a list of number inputs inside a two-column desktop grid. On a phone, mid-set, you are
looking at a form.

This handoff specifies a redesign of the workout experience around one idea: **while a workout is
running, the app is a game, not a form.**

1. Starting a workout enters **arena mode** — a dark, full-screen view that replaces the page chrome.
2. Exactly **one set** is on screen at a time: a giant rep count inside a progress ring, and one button.
3. Rest is a **loading screen**, not a banner: countdown ring, what's next, one coach line.
4. Finishing produces a **reward screen** — XP count-up, stars, level progress, new achievements, PRs.
5. A **hologram of the exercise pose** loops above the set at the prescribed tempo, so form is on screen
   at the moment it matters — with a full-screen form-check view behind one tap.
6. Outside the workout, the calisthenics progressions become a **quest path** whose stations are
   conquered by *count of workouts done*, not by a manual "כבשתי!" button.

**Chosen direction: `1a` (the arena).** The design file also contains `1b` ("לוח המסע" — a light board-game
treatment) in full; it is a rejected alternative kept for reference. Turn 2 in the same file (`2a`–`2d`)
is the rest of `1a`: player profile, quest map, empty state, and the layers that open over the arena.
Turn 3 (`3a`–`3b`) adds the exercise hologram to the arena — `3a` supersedes turn 1's frame 2 as the
**current spec for the active-set screen**.

> **Blocked on one asset.** The hologram's figure is deliberately a placeholder in the prototype — the
> holographic shell (glow, scan sweep, grid, plinth, labels) is designed; the person is not drawn. Section
> *Screen 9* lists the two asset options. **Do not hand-draw a figure in SVG/CSS** to fill the gap; ship the
> arena without the hologram until a real asset exists (the fallback is specified and is not a broken state).

## About the Design Files

`Training Game.dc.html` in this bundle is a **design reference created in HTML** — a static prototype of
the intended layout, spacing, type, color and motion. It is **not production code and must not be copied
into the app**. It is a Design Component file with a custom runtime (`support.js`) and has no relationship
to the app's Jinja/Tailwind stack.

The task is to **recreate these designs inside the existing codebase**: Python/FastAPI serving Jinja2
templates in `app/frontend/templates/`, styled with Tailwind (CDN) plus `app/frontend/static/css/main.css`,
with vanilla JS (`app/frontend/static/js/workout.js`) for interactions. Use the app's established patterns —
no framework, no build step, no new tooling.

The app is **Hebrew, RTL** (`<html lang="he" dir="rtl">`). Every layout below is described in logical terms
(start/end). All copy in this document is the exact Hebrew string to use — **except rank titles**, see
*Reusing the existing engine*.

## Fidelity

**High-fidelity.** Colors, type sizes, weights, radii and spacing in the prototype are final and listed in
*Design Tokens*. Recreate to those values, as Tailwind utilities where one matches exactly and arbitrary
values (`text-[13px]`) where it doesn't. The prototype frames are 352×720 CSS px (≈ iPhone viewport with
bezel); the real implementation must be fluid from 320px up to the `md:` breakpoint.

**Arena mode is mobile-first but not mobile-only.** At `md:` and up, keep the current two-column page for
history/skills, and render the arena as a centered 480px-max column on the same dark background. Do not
ship a desktop-only experience and a separate mobile one.

---

## Reusing the existing engine (read this before writing any number)

Everything the design shows already exists in `app/backend/app/routes/workouts.py`. **Do not invent a second
XP formula in JS.** The server computes:

| Value | Source | Notes |
|---|---|---|
| Session XP | `_session_xp()` | `50 + 10×sets + 1×reps + 2×minutes` (minutes capped at 120) |
| Level / progress | `_level_from_xp()` | level N→N+1 costs `100 + (N-1)×75` |
| Rank + next rank | `RANKS` / `_rank_for_level()` | **Use these exact titles** — טירון ברזל, חניך מתאמן, לוחם רחוב, לוחם מתקדם, אלוף השכונה, מאסטר קליסטניקס, אגדה חיה |
| Streak | `_compute_streak()` | consecutive days ending at the latest workout |
| Achievements | `compute_gamification()` | id, icon, title, desc, current, target, unlocked |
| Progressions | `SKILLS_GUIDE` | per skill: title, difficulty, muscles, warmup, cues, progressions[{name, hebrew, reps, rest}] |

The prototype shows placeholder rank strings ("לוחם מתעורר", "לוחם ברזל") purely as visual filler.
**Ship the real `RANKS` titles and the real `fa-*` icons** (or a systematic emoji mapping — see *Assets*).

The client mirrors the formula *only* for the live in-session counter (`XP_PER_SET = 10` already exists in
`workout.js`). On save, the server number wins: the reward screen must render the value returned by the
save response, not the locally accumulated one.

---

## Screens / Views

### 1. Arena — active set (`1a`, frame 2) — the core screen

Entered by "כניסה לזירה". While it is open: bottom tab bar hidden, page scroll locked, wake lock requested
(already implemented in `workout.js`).

**Background:** `radial-gradient(118% 66% at 50% 16%, #3b2a7d 0%, #171338 52%, #0b0a1c 100%)`.

- **Status row** (44px, `padding:0 18px`): start `תרגיל 2 מתוך 5 · 14:22` Rubik 400 12px `#c7d2fe`
  (elapsed time in JetBrains Mono, `dir="ltr"`); end live session XP — JetBrains Mono 700 19px `#facc15` + ⭐.
- **Exercise progress rail:** one 4px `border-radius:999px` segment per exercise, `gap:5px`, `padding:0 18px`.
  Done `#22c55e`, current `#facc15`, future `rgba(255,255,255,.16)`.
- **Set label:** `סט 3 מתוך 4` Rubik 700 13px `#a5b4fc`.
- **The ring:** 212px circle, `background:conic-gradient(#facc15 0 <pct>%, rgba(255,255,255,.12) <pct>% 100%)`
  where `<pct>` = sets completed in this exercise. Inner disc `inset:12px`, `#100e2a`, holding the rep count —
  **JetBrains Mono 800 78px `#fff`, `dir="ltr"`** — over `חזרות` Rubik 600 12px `#a5b4fc`.
  A `#facc15` pill (`+22 XP`, Rubik 700 11px `#42300a`) overhangs the top edge. The ring breathes with a
  2.6s `box-shadow` pulse; **no library, no canvas.**
- **Exercise name** Heebo 800 21px `#fff`; below it the comparison line Rubik 400 12px `#a5b4fc`:
  `בפעם שעברה עשית 11 — עוד אחת והשיא נשבר`. When there is no history for the exercise, this line is omitted
  entirely (no "0 חזרות").
- **Rep steppers:** two 52px `border-radius:16px` tiles (− / +) flanking the label `כוונון חזרות`.
  These replace the current `.stepper-input` number field on this screen; the typed input stays available in
  the exercise sheet (`2d`) for corrections.
- **Combo pill** (only at ×2 and above): `🔥 קומבו ×3 · בונוס 15%`, Rubik 700 11px `#fdba74`,
  `background:rgba(249,115,22,.18)`, `border:1px solid rgba(251,146,60,.4)`.
- **Primary action:** 62px, `border-radius:20px`, `linear-gradient(135deg,#16a34a,#22c55e)`,
  `box-shadow:0 14px 30px -12px rgba(34,197,94,.9)` — `✓ סיימתי את הסט` Heebo 800 19px `#fff`.
- **Secondary row:** `דילוג על הסט` / `כל התרגילים`, both 44px, `rgba(255,255,255,.07)`, Rubik 500 13px `#c7d2fe`.

**On completing a set:** the set tile fills, `+XP` floats up from the button (the existing `.xp-float`
animation), the ring advances, and the app transitions to the rest screen. No modal, no confirm.

### 2. Arena — rest (`1a`, frame 3)

Replaces the current fixed bottom banner (`#rest-timer-banner`). Teal background
(`radial-gradient(110% 60% at 50% 20%, #134e4a, #0f2b3d 50%, #0b0a1c)`) so the mode change is unmistakable.

- Eyebrow `מנוחה` Rubik 700 11px `#5eead4` `letter-spacing:.1em`
- 196px countdown ring, `conic-gradient(#2dd4bf 0 <pct>%, rgba(255,255,255,.1) ...)`, inner disc `#08252a`,
  `0:47` JetBrains Mono 800 56px `#fff` `dir="ltr"` over `עד הסט הבא`
- Controls: `−10s` / `+10s` (40px, `rgba(255,255,255,.07)`, JetBrains Mono 600 13px) and `אני מוכן` (40px, `#0d9488`)
- **הבא בתור** card: 44px icon tile, `שכיבות סמיכה · סט 4` Heebo 700 15px, sub-line + `+22` in `#facc15`
- **מהמאמן** card: one calm sentence, Rubik 400 12.5px `#e5e7eb`. Rotate from a small static list keyed to the
  exercise category — this is copy, not AI. Never more than two lines.
- **Session strip:** `האימון עד עכשיו` + `240 XP` + `9 סטים`, `rgba(250,204,21,.1)` / `#fde047`

Keep the existing absolute-timestamp countdown (`restEndsAt`) so backgrounding the browser can't drift it,
and keep the `timer-finished` state — as a `#dc2626` ring and a single vibration, not a pulsing banner.

### 3. Arena — reward screen (`1a`, frame 4)

Full-screen, `radial-gradient(100% 55% at 50% 8%, #4c1d95, #1e1b4b 45%, #0b0a1c)`, confetti falling from the
top edge (5–12 absolutely positioned 7–9×12–15px `border-radius:2px` rects, `fallSpin` 3–4s, staggered).

- 84px trophy disc, `linear-gradient(145deg,#fde047,#d97706)`, `box-shadow:0 0 0 6px rgba(250,204,21,.16)`, slow bob
- `האימון הושלם` Heebo 800 26px `#fff`; sub-line `38 דקות · 18 סטים · 214 חזרות`
- **Three stars**, earned by rule: ① finished the workout ② ≥ the planned number of sets
  ③ no skipped set. Unearned stars render at `opacity:.28` with the reason line underneath
  (`הכוכב השלישי: לסיים בלי לדלג על סט`) — **always say how to get the missing star.**
- XP card: `+340 XP` JetBrains Mono 800 32px `#facc15`, **counting up from 0 over ~900ms**; level line
  `שלב 7 ← 8`, progress bar, and `עוד 160 XP לדרגת <rank>`
- **Achievement rows** (only when actually unlocked this session): gold-tinted card, 42px tile, title + desc
- **PR row** (only on a real personal record): green card, `שיא אישי · 12 חזרות` + `השיא הקודם היה 11 · לפני 9 ימים`
- Primary: `חזרה למפת המסע` — white, Heebo 800 16px `#312e81`

This replaces `#victory-modal`. The existing star/confetti/level-up CSS in `workout.html` is a good starting
point; it just needs to become a full screen rather than a card in a scrim.

### 4. Pre-workout — quest select (`1a`, frame 1)

The page you land on when not training. Dark `#0f0e24`, 40px header (`אימונים` + level/XP pill).

- **המשימה של היום** hero card: `linear-gradient(150deg,#312e81,#5b21b6 55%,#7c3aed)`, `border-radius:22px`,
  with a slow sheen sweep. Title = the active path and station (`מסלול הדחיפה · שלב 4`), sub-line
  `5 תרגילים · 18 סטים · בערך 38 דקות` (estimate from the user's own history for the same path),
  a 5-segment station progress bar, a `שכר צפוי +320 XP` pill, `האחרון: לפני יומיים`, and a 50px white
  `כניסה לזירה` button.
- **מסלולים אחרים** list: 34px icon tile + name + `14 סטים · +260 XP`; locked paths are dashed with
  `נפתח בשלב 10` and are **not** tappable.
- **Streak strip:** `🔥 רצף 6 ימים` + seven 26px day cells, filled `rgba(250,204,21,.9)`, today dashed.
  Sub-line `עוד אימון אחד השבוע ליעד`.

### 5. Player profile (`2a`)

Replaces the current player card + achievements tab. Header gradient `linear-gradient(165deg,#312e81,#4c1d95 60%,#1e1b4b)`
with a 96px level ring (`conic-gradient` on `progress_pct`), rank title Heebo 800 19px, XP bar and
`1,840 / 2,000` in JetBrains Mono.

- 2×2 career stat tiles (אימונים / סטים / חזרות / הרצף הארוך — the streak tile in orange)
- **סולם הדרגות:** one row per `RANKS` entry — achieved (dimmed, `הושג`), current (gold border, `הדרגה שלך`),
  next (dashed, with the XP remaining). Scrolls; the current rank is scrolled into view on open.
- **הישגים** grid, 4 columns, 58px tiles: unlocked = gold gradient + icon; locked = `rgba(255,255,255,.06)`
  with 🔒 and its `current/target` in JetBrains Mono 9.5px.
- Scroll container needs **≥78px bottom padding** to clear the 62px tab bar.

### 9. Exercise hologram (`3a`, `3b`) — **supersedes screen 1's middle block**

A holographic figure demonstrating the exercise pose, looping at the exercise's prescribed tempo. It sits
inside the arena, above the set, and is the reason the rep count shrinks from 212px to a 118px ring.

**Asset — decide before building (blocking):**

| Option | Cost | What it enables |
|---|---|---|
| **A · 24-frame `webp` sequence per exercise** | ~40–80 KB per exercise, works on any phone | loop, tempo scaling, fixed camera angles (one sequence per angle) |
| **B · one `glb` with a clip per exercise** | heavier, needs a WebGL viewer | drag-to-rotate 360°, free camera, one file for everything |

Option A is the recommended default — it covers everything in `3a` and all of `3b` except free rotation, with
no 3D dependency. **An exercise with no asset falls back silently to the turn-1 arena layout** (212px ring, no
stage). Never render an empty hologram frame.

#### 9.1 In-set hologram (`3a`)

Stage: 226px tall, `border-radius:24px`, `background: radial-gradient(78% 62% at 50% 38%, rgba(34,211,238,.2),
rgba(13,148,136,.08) 46%, rgba(11,10,28,0) 78%), #0c1230`, `border:1px solid rgba(103,232,249,.22)`.

- **Grid:** two `linear-gradient(rgba(103,232,249,.08) 1px, transparent 1px)` layers at `background-size:26px 26px`
- **Scan sweep:** a 34px band, `linear-gradient(180deg, transparent, rgba(103,232,249,.26), transparent)`,
  translating top→bottom on a 3.6s linear loop
- **Corner brackets:** four 18px `2px solid #67e8f9` L-shapes, 10px inset, 6px outer radius
- **Status pill** (top-start, 36px in): pulsing 6px `#22d3ee` dot + `מנח התרגיל · לופ` Rubik 700 10px `#a5f3fc`
- **Figure slot:** inset `top:44px bottom:42px`, start 24px / **end 66px** (clearing the control tiles),
  `1.5px dashed rgba(103,232,249,.45)`, `border-radius:16px`. In production this is the asset, edge-to-edge.
- **Plinth:** 168×16px `radial-gradient` ellipse, 18px from the stage bottom, breathing on a 2.8s loop
- **Controls** (end side, stacked, 38px tiles, `rgba(8,37,42,.7)` + `1px solid rgba(103,232,249,.34)`):
  `🔄 זווית` cycles camera angle · `.5× האט` halves the loop speed. Both are 38px visual but need a 44px hit area.
- **Whole stage** flickers on a 5.5s `opacity:.86→1` cycle — subtle, and off under `prefers-reduced-motion`.

**Tempo strip** — a separate row **below** the stage (not inside it): `מקצב` Rubik 700 9.5px `#67e8f9`, a
3-segment bar (`flex:3/1/1`, 5px, active `#22d3ee`, rest `rgba(103,232,249,.38)`), and the tempo in JetBrains
Mono 600 9.5px `#a5f3fc` `dir="ltr"`. The segments map to eccentric–pause–concentric and animate in sync with
the hologram loop.

**Rep ring, repositioned:** 118px (down from 212px), `conic-gradient` unchanged, inner disc `inset:8px` `#100e2a`,
rep count **JetBrains Mono 800 46px `#fff`**, `חזרות` Rubik 600 10px below it. The `+22 XP` pill overhangs the
top edge, centered with `left:50%; transform:translateX(-50%)` — **not** an `inset-inline` idiom, which does not
center correctly in this RTL context. Beside the ring (block start-aligned): `סט 3 מתוך 4`, exercise name
Heebo 800 19px, and the PR comparison line.

The 46px rep count is the one deliberate concession to the "legible from the floor" rule — the hologram now
carries that distance-reading job. If the asset ships late, keep the 212px ring until it lands.

**Third action:** `🫥 בדיקת תנוחה` — a 52px tile between the − / + steppers,
`rgba(34,211,238,.13)` + `1px solid rgba(103,232,249,.34)`, Rubik 700 13px `#a5f3fc`. Opens 9.2.

#### 9.2 Form check (`3b`)

Full screen over the arena, `radial-gradient(110% 58% at 50% 22%, #0e3a4a, #0c1230 52%, #0b0a1c)`.
Header: exercise name Heebo 800 17px + `סגור`.

- **Stage** 348px, same holographic treatment at 30px grid and a 4.2s sweep
- **Cue pins:** two numbered 22px `#22d3ee` discs with `rgba(8,37,42,.72)` chips — one anchored near the stage
  top, one near the bottom, **outside the figure slot's band**. Text comes from the first two entries of the
  exercise's existing `cues` array; never show more than two.
- **Angle row** (stage bottom): `צד` / `חזית` / `מלמעלה`, 34px, active tile `rgba(34,211,238,.2)` +
  `1px solid rgba(103,232,249,.44)`. With asset option B this row becomes drag-to-rotate and the chips
  are presets.
- **Tempo card:** the same 3-segment bar at 7px plus the legend `ירידה · עצירה · דחיפה`
- **שתי נקודות לתיקון:** the same two cues as full sentences, Rubik 400 12px `#e5e7eb`, numbered to match the pins
- **Primary:** `חזרה לסט` — white, 56px, Heebo 800 16px `#0e3a4a`

Opening this screen **does not pause** the workout or the rest timer. It is a look, not a mode.

### 6. Quest map (`2b`)

The `SKILLS_GUIDE` progressions, redrawn as a path. Rail: 3px `rgba(255,255,255,.1)` line at logical start,
with the completed portion painted `#facc15`.

- **Conquered** station: 40px `#facc15` tile with ✓, card at `opacity:.6`, title line-through, `נכבש · 12 אימונים`
- **Current** station: `#facc15` tile with the 🧍 token, `box-shadow:0 0 0 5px rgba(250,204,21,.16), 0 0 22px rgba(250,204,21,.45)`,
  card with `3 מתוך 5 אימונים לכיבוש · 8–12 חזרות`, 5-segment bar, and the `כניסה לזירה` button
- **Next** station: dashed tile with its number, `נפתח אחרי 2 אימונים נוספים`
- **Locked** stations: 🔒 tile, name only, `opacity:.65`
- **Goal** card at the top: 👑 gold tile, `יעד המסלול · פלאנש מלא` + `5 תחנות משם · לפי הקצב שלך, בערך 4 חודשים`
  (estimate = remaining stations × the user's median workouts-per-station; omit the estimate with <3 workouts of history)
- Coach note at the foot: `תחנה נכבשת כשהשלמת 5 אימונים איתה בטווח החזרות — לא צריך לסמן כלום ידנית.`

**This removes the "כבשתי!" button** (`toggleStageComplete`) and its `localStorage` progress. See *Backend*.

### 7. Empty state — first workout (`2c`)

No history at all. One screen, no dashboards, no zero counters:
🗺️ tile → `המסע מתחיל בשלב 1` Heebo 800 24px → `בחר מסלול אחד להתחיל איתו. אפשר להחליף בכל רגע — ההתקדמות
נשמרת לכל מסלול בנפרד.` → three path cards (the first emphasized) → `האימון הראשון שווה +100 XP` strip →
a quiet text link `או התחל אימון חופשי בלי מסלול` (the current free-form flow, kept).

### 8. Layers over the arena (`2d`)

Both open **on top of** the arena at `rgba(11,10,28,.62)` — the workout is never left.

- **PR toast:** green gradient card, 22px inset from the edges, `📈 שיא אישי חדש` + detail + `+40`.
  Auto-dismiss after 2.5s, tap to dismiss. Fires at most once per exercise per session.
- **Exercise sheet:** `#141131`, `border-radius:26px 26px 0 0`, 38×4 grab handle, `האימון של היום` Heebo 800 17px,
  one row per exercise with state colors (done green `4/4`, current gold `3/4`, upcoming neutral `0/4`),
  then `הוסף תרגיל` and `סיום מוקדם` (red-tinted, `rgba(220,38,38,.16)`). Dismiss by handle drag, scrim tap,
  or `סגור`. Trap focus while open; return focus to the trigger.

---

## Interactions & Behavior

- **Entering/leaving arena mode:** `body.arena-open` hides the bottom tab bar and locks scroll (reuse the
  existing `body.modal-open` technique so iOS doesn't scroll behind). Leaving restores scroll position.
- **One set per screen:** advancing is automatic — complete set → rest → next set. `דילוג על הסט` advances
  without XP. Going back is possible only through the exercise sheet.
- **Optimistic everything:** the set is marked done and XP added locally the moment the button is pressed;
  the session is already persisted to `localStorage` (`workout_active_session_v2`) — keep that key and its
  resume-after-refresh behavior, including resuming **into arena mode**.
- **Combo:** unchanged rule (consecutive completed sets, broken by unchecking). It now also breaks if rest
  runs more than 90s over the planned rest — surface that as the rest-screen line
  `שמור על הקומבו — התחל את הסט הבא תוך 90 שניות`.
- **Hologram:** loops continuously while the set screen is open; pauses during rest (the rest screen has its
  own ring) and on `visibilitychange` to save battery. Preload only the current and next exercise's asset.
  The angle choice is remembered per exercise; the `.5×` speed resets each session.
- **Motion:** ring pulse 2.6s, token/trophy bob 2.8s, XP float 1.2s, confetti 3–4s, XP count-up ~900ms,
  sheet slide-up 240ms ease-out, scrim fade 160ms. **All of it must respect `prefers-reduced-motion`** —
  confetti and pulses off, count-up becomes an instant value. For the hologram this means: no flicker, no scan
  sweep, no plinth breathing — the loop itself stays (it is content), but a single static pose frame with the
  cues visible is an acceptable reduced-motion substitute.
- **Haptics:** `navigator.vibrate(12)` on set complete, `[40,60,40]` on rest end, `[30,50,30,50,80]` on level-up.
  Guard for absence; never vibrate in `prefers-reduced-motion`.
- **Touch targets:** 44px minimum everywhere; the rep steppers are 52px and the primary action 62px.
- **Screen stays awake:** existing wake-lock code covers this; re-request on `visibilitychange`.

## State Management

Vanilla JS, no framework. On top of the existing session state:

| State | Scope | Trigger |
|---|---|---|
| `arenaOpen` | global | start/resume workout, exit |
| `currentExerciseIndex`, `currentSetIndex` | session | set complete / skip / pick from sheet |
| `phase` (`set` / `rest` / `reward`) | session | set complete, rest end, finish |
| `sessionXp`, `comboCount` | session | set complete (existing) |
| `activePath`, `activeStation` | persisted | path pick on quest map |
| `sheetOpen` | arena | "כל התרגילים", add-exercise |
| `prShown[exerciseId]` | session | PR toast fired |
| `holoAngle[exerciseId]`, `holoSlow` | persisted / session | angle tile, `.5×` tile |
| `formCheckOpen` | arena | "בדיקת תנוחה" |

Persist `activePath` and the resumable session under the existing namespaced keys. Do not touch unrelated
`localStorage` keys.

## Backend

Small and mostly derived — the engine already exists.

1. **Station progress (`2b`)** — the only real change. Replace the client-side "כבשתי" flag with a count:
   store `skill_key` + `stage_index` on a saved workout (two nullable columns on the workout row, or a small
   `workout_stage` table), and derive `stage_sessions = COUNT(*)` per station. Conquered = 5 sessions in the
   station's rep range. Migrate existing `localStorage` "conquered" flags on first load if present, then stop
   reading them.
2. **Personal records (`1a` frame 2, `2d`)** — `MAX(reps)` per exercise name from history. Return it with the
   page payload so the arena can show "בפעם שעברה עשית 11" without a request per set.
3. **Session estimate** — `5 תרגילים · 18 סטים · בערך 38 דקות`: median duration of the user's last 5 sessions on
   the same path. No new storage.
4. Everything else — XP, level, rank, streak, achievements — is already computed in `compute_gamification()`.

## Design Tokens

**Arena neutrals/darks:** `#0b0a1c` `#0f0e24` `#100e2a` `#141131` `#151233` `#171338` `#1e1b4b` `#312e81`
`#3b2a7d` `#4c1d95` `#5b21b6` — plus overlays `rgba(255,255,255,.05/.06/.07/.08)` and borders
`rgba(255,255,255,.09/.12/.14)`.

**Text on dark:** `#fff` · `#e5e7eb` · `#c7d2fe` · `#c4b5fd` · `#a5b4fc` (meta floor) · `#9ca3af` (disabled only).
Never lighter than `#9ca3af` for meta, never below 10px.

**Accents:** gold `#facc15` / `#fde047` / `#fcd34d` / `#d97706` (XP, current, rewards) · indigo `#4f46e5` / `#7c3aed`
(app, paths) · green `#16a34a` / `#22c55e` / `#86efac` (done, PR) · teal `#0d9488` / `#2dd4bf` / `#5eead4` (rest) ·
orange `#f97316` / `#fb923c` / `#fdba74` (streak, combo) · red `#dc2626` / `#fca5a5` (skip, end early).

**Type:** Rubik 300/400/500/600/700 (UI + Hebrew body) · Heebo 700/800/900 (headings) ·
JetBrains Mono 400/500/600/700/800 (**all numbers, always `dir="ltr"`**).
Sizes in use: 10 · 10.5 · 11 · 11.5 · 12 · 12.5 · 13 · 14 · 15 · 16 · 17 · 19 · 20 · 21 · 24 · 26 · 30 · 32 · 34 · 54 · 56 · 78px.

**Spacing:** 2 · 3 · 4 · 5 · 6 · 7 · 8 · 9 · 10 · 11 · 12 · 13 · 14 · 16 · 18 · 20 · 22 · 24 · 26px.
Screen gutter 16–18px · card padding 11–18px · block gap 12–14px.

**Radii:** 10 (small tile) · 12–14 (tile, row) · 15–16 (button, card) · 18 (feature card) · 20 (primary action) ·
22 (hero) · 26 (sheet) · 999 (rings, pills, bars).

**Shadows:** hero `0 18px 34px -16px rgba(124,58,237,.85)` · primary `0 14px 30px -12px rgba(34,197,94,.9)` ·
ring glow `0 0 38px -6px rgba(250,204,21,.34)` → `0 0 58px 0 rgba(250,204,21,.6)` ·
sheet `0 -14px 44px -10px rgba(0,0,0,.6)` · phone `0 24px 60px -18px rgba(17,24,39,.42)`

**Hologram cyan:** `#22d3ee` `#67e8f9` `#a5f3fc` `#cffafe` · stage `#0c1230` · deep teal `#0e3a4a` `#062b33` ·
surfaces `rgba(8,37,42,.66/.7/.72)` · lines/borders `rgba(103,232,249,.08/.22/.3/.34/.44/.45)`

**Scrim:** `rgba(11,10,28,.62)`

**Hologram motion:** scan sweep 3.6s (in-set) / 4.2s (form check) linear · stage flicker 5.5s ease-in-out ·
plinth 2.8s ease-in-out · status dot 1.6s

## Assets

**The hologram needs a real asset — this is the one hard dependency in the whole redesign.** Per exercise,
either 24 `webp` frames (option A) or a clip in a shared `glb` (option B); see *Screen 9*. Serve from
`app/frontend/static/holo/<exercise_key>/`, lazy-loaded, with the fallback path tested first so exercises
without an asset are never broken. The 🫥 glyph in the prototype marks the slot and ships nowhere.

Otherwise no image assets. The prototype uses emoji (🏋️ 💪 🧗 🌀 🗺️ 🧍 👑 🔒 🎖️ 🔥 💯 📈 🏆 🏁 🎯 ⚔️ 🛡️ 🥉), while the app
today uses Font Awesome (`fa-dumbbell`, `fa-fire`, `fa-trophy`, and the `icon` field on each rank and
achievement). **Pick one and apply it everywhere** — the simplest path is to keep Font Awesome for
ranks/achievements (the data already carries `fa-*` names) and use emoji only for the path/station icons,
which have no server-side icon field. Do not mix the two inside one list.

Fonts load from Google Fonts; `main.css` declares the families once.

## Files

**In this bundle (design references — do not ship):**
- `Training Game.dc.html` — turn 1: `1a` (build this) and `1b` (rejected alternative);
  turn 2: `2a`–`2d` (the rest of `1a`); turn 3: `3a`–`3b` (the hologram; `3a` replaces turn 1's frame 2).
  Newest turn is at the top of the canvas.
- `support.js` — runtime required to open the design file in a browser. Irrelevant to the app.

**Repo files this change touches** (paths relative to repo root):
- `app/frontend/templates/pages/workout.html` — arena mode markup (set / rest / reward), quest select,
  profile, quest map, empty state, exercise sheet; remove `#victory-modal` and `#rest-timer-banner` in favor
  of the full-screen phases
- `app/frontend/static/js/workout.js` — phase machine (`set`/`rest`/`reward`), one-set-at-a-time rendering,
  PR detection, count-up, haptics, reduced-motion guards; keep session persistence, wake lock and the
  absolute-timestamp rest countdown as they are
- `app/frontend/static/css/main.css` — arena mode (`body.arena-open`), rings, sheet, confetti, float/pulse
  keyframes (several already exist inline in `workout.html` — move them here), plus the hologram stage,
  scan sweep, flicker and plinth keyframes
- `app/frontend/static/holo/` — new: the per-exercise hologram assets
- `app/backend/app/routes/workouts.py` — expose `tempo` and `holo_key` per exercise alongside the existing
  `cues` (the form-check screen reads all three)
- `app/backend/app/routes/workouts.py` — station progress counting, personal records, session estimate;
  `RANKS`/XP/achievements unchanged
- `app/backend/app/db.py` — `skill_key` + `stage_index` on saved workouts (or the `workout_stage` table)

## Suggested build order

1. **Arena shell** — `body.arena-open`, dark full-screen container, enter/exit, tab bar hidden. Nothing else changes yet.
2. **One set per screen** — ring, giant rep count, steppers, primary button, exercise rail. This is the whole idea; ship it first.
3. **Rest as a screen** — replace the banner, keep the timestamp countdown.
4. **Reward screen** — replace the victory modal; XP count-up from the server's returned value, stars, PR row.
5. **Quest select** — today's mission card, other paths, streak strip.
6. **Personal records** — `MAX(reps)` per exercise, the comparison line and the PR toast.
7. **Quest map** — station counting, remove "כבשתי!" and its `localStorage`.
8. **Player profile** — rank ladder and achievement grid in the new layout.
9. **Empty state** — first-run path pick.
10. **Exercise sheet** — the one layer that lets you correct anything mid-workout.
11. **Hologram stage** (`3a`) — once an asset exists: stage chrome, loop, tempo strip, the 118px ring layout,
    angle/slow controls, and the no-asset fallback.
12. **Form check** (`3b`) — cue pins, angle presets, tempo legend.

Steps 11–12 are gated on the asset decision and can ship in a later release without touching 1–10 —
the arena is designed to be complete without them.

## Acceptance checks

- Starting a workout hides the bottom tab bar and shows exactly one set; no other UI is reachable by scroll.
- The rep count is legible from ~1.5m (78px mono) — check on a real phone on the floor, not in a simulator.
- Every number in the app renders LTR inside the RTL layout.
- Refreshing mid-workout resumes into arena mode at the same exercise and set, with the timer correct.
- The XP shown on the reward screen equals the server's value for that session, not a client estimate.
- No zero states: no empty achievement rows, no PR row without a real record, no station estimate without history.
- With `prefers-reduced-motion: reduce`, nothing pulses, falls, or counts up — and no functionality is lost.
- Rank titles on screen match `RANKS` in `workouts.py` exactly.
- A station is conquered by completing 5 workouts with it; there is no manual "conquer" button anywhere.
- Every interactive element passes a 44px touch-target check.
- At `md:` and up the history and skills columns still work, and the arena renders as a centered column.
- An exercise with no hologram asset renders the turn-1 arena (212px ring) with no empty frame and no layout shift.
- The hologram loop matches the exercise's tempo, and `.5×` visibly halves it.
- The tempo strip sits **below** the hologram stage and is never covered by the rep ring or the XP pill
  (this was a real defect in the prototype; the fix is in the spec above).
- The `+22 XP` pill is horizontally centered on the ring in RTL.
- Opening בדיקת תנוחה does not pause the rest timer or lose the set in progress.
- The hologram stops looping when the tab is hidden.
